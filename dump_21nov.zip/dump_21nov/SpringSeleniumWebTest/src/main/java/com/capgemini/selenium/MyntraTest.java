package com.capgemini.selenium;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;


public class MyntraTest {
	private String baseUrl = "https://www.myntra.com/";
	private String path_to_driver = "D:\\srinivas_12sep_garg\\4th_6nov(TopUP)\\Spring_content_5nov\\github_sirinivas\\";
	private WebDriver driver;

	@Test
	public void verifyMyntra() {
		try {
		System.setProperty("webdriver.chrome.driver", path_to_driver + "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get(baseUrl);
		WebElement searchelement = driver.findElement(By.className("desktop-searchBar"));
		//By.xPath("//input[@class='desktop-searchBar']")
		searchelement.sendKeys("mobile"); // send also a "\n"
		searchelement.sendKeys(Keys.RETURN);
		String path_to_puma="//*[@id='mountRoot']/div/main/div[3]/div[1]/section/div/div[3]/ul/li[3]/label/input";
		WebElement checkboxelement = driver.findElement(By.xpath(path_to_puma));
		Actions actions = new Actions(driver);
		actions.moveToElement(checkboxelement);
		actions.click().perform();
		String path2="//*[@id=\"desktopSearchResults\"]/div[2]/section/ul/li[1]/a/div[1]";
		WebElement firstimage = driver.findElement(By.xpath(path2));
		actions.moveToElement(firstimage );
		actions.perform();

		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			driver.quit();
		}
	}


}
