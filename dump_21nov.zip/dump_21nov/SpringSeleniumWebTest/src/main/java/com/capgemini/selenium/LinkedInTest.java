package com.capgemini.selenium;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class LinkedInTest {
	private String baseUrl = "https://in.linkedin.com/";
	private String path_to_driver = "D:\\srinivas_12sep_garg\\4th_6nov(TopUP)\\Spring_content_5nov\\github_sirinivas\\";
	private WebDriver driver;

	@Test
	public void linkedinTest() {
		try {
		System.setProperty("webdriver.chrome.driver", path_to_driver + "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get(baseUrl);
		WebElement firstnameelement = driver.findElement(By.id("reg-firstname"));
		WebElement lastnameelement = driver.findElement(By.id("reg-lastname"));
		WebElement emailelement = driver.findElement(By.id("reg-email"));
		WebElement passwordelement = driver.findElement(By.id("reg-password"));
		WebElement submitelement = driver.findElement(By.id("registration-submit"));
		firstnameelement.sendKeys("Test");
		lastnameelement.sendKeys("modi");
		emailelement.sendKeys("testmodi3101@gmail.com");
		passwordelement.sendKeys("Modi@12345");
		Thread.sleep(3000);
		submitelement.click();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			driver.quit();
		}
	}



}
