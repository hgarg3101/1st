package com.capgemini.selenium;




import org.junit.Assert;


import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GoogleTest {
	private String baseUrl = "http://www.google.co.in/";
	private String path_to_driver = "D:\\srinivas_12sep_garg\\4th_6nov(TopUP)\\Spring_content_5nov\\github_sirinivas\\";
	private WebDriver driver=null;

	@Test
	public void verifyHomePageTitle() {
		try {
		System.setProperty("webdriver.chrome.driver", path_to_driver + "chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(baseUrl);
//		WebElement element = driver.findElement(By.name("q"));
//		element.sendKeys("Cheese!\n"); // send also a "\n"
//		element.submit();
		Assert.assertEquals(driver.getTitle(),"Google");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			driver.quit();
		}
	}
	



}
