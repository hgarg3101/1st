package com.capgemini.selenium;

import java.util.List;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class PizzaTest {
	private String baseUrl = "http://localhost:8987/SpringSeleniumWebTest/pitza.html";
	private String path_to_driver = "D:\\srinivas_12sep_garg\\4th_6nov(TopUP)\\Spring_content_5nov\\github_sirinivas\\";
	private WebDriver driver;

	@Test
	public void verifyPizza() {
		try {
		System.setProperty("webdriver.chrome.driver", path_to_driver + "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get(baseUrl);
		WebElement element = driver.findElement(By.id("name"));
		element.sendKeys("Harshit"); // send also a "\n"
		WebElement checkbox = driver.findElement(By.id("pizza"));
		checkbox.click();
		WebElement checkbox1 = driver.findElement(By.id("Pizza1"));
		checkbox1.click();
		WebElement checkbox2 = driver.findElement(By.id("Pizza2"));
		checkbox2.click();
		Select select = new Select(driver.findElement(By.id("sel")));
		select.deselectAll();
		select.selectByVisibleText("Tomato");
		List<WebElement> checkbox4 = driver.findElements(By.name("Pizza"));
		
		//checkbox for pizza topping
		for(int i=0;i<checkbox4.size();i++) {
			String str = checkbox4.get(i).getAttribute("value");
			if(str.equals("Extra Cheese")) {
				if(!checkbox4.get(i).isSelected()) {
					 checkbox4.get(i).click();
				}
			}
		}
		//
		WebElement element1 = driver.findElement(By.id("instructions"));
		element1.sendKeys("Extra napkins..extra ketchup");
		
		WebElement element2=driver.findElement(By.xpath("//input[@type='button']"));
		if(element2.getAttribute("value").equals("Send my order")) {
			element2.click();
		}
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			driver.quit();
		}
	}

}
