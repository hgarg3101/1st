package com.capgemini.SpringJunitDemo;

/**
 * Hello world!
 *
 */
public class App 
{
    public long add(String string,String string2) {
    	return Long.valueOf(string)+Long.valueOf(string2);
    }
    
	public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
