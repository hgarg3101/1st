package com.capgemini.SpringJunitDemo;

import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import junit.framework.Assert;

public class Test2 {
	int a;
	@Before //every test case
	public void inita() {
		System.out.println("Before annotated method\nInput 1 to run test");
		Scanner s = new Scanner(System.in);
		a=s.nextInt();
	}
	
	@Test
	public void tested() {
//		System.out.print("1");
		if(a==1) {
			System.out.print("1");
			Assert.assertEquals(new com.capgemini.SpringJunitDemo.App().add("1","2"),
					3);
		}
		else {
			Assert.fail("wrong input");
		}
//			
	}
	@Test
	public void tested2() {
//		System.out.print("2");
		if(a==1)
			Assert.assertEquals(new com.capgemini.SpringJunitDemo.App().add("1","2"),
					3);
	}
	@After //every test case
	public void lasts() {
		System.out.println("Testing done...");
	}
	
}
