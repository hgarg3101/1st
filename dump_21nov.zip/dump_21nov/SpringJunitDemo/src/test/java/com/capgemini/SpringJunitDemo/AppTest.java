package com.capgemini.SpringJunitDemo;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
	@Before
	public void displaypre() {
		System.out.println("Pre hook");
	}
    
	@After
	public void displaypost() {
		System.out.println("Post hook");
	}
	
    @Test(timeout=10)
    public void shouldAnswerwithTrue() {
    	for(int i=0;i<100;i++) {
    		System.out.println("i="+i);
    	}
    }
    
    
}
