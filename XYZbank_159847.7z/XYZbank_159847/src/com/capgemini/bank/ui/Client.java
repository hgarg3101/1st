package com.capgemini.bank.ui;


import java.sql.SQLException;

import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;

public class Client {
	public static void main(String...a) throws SQLException{
		Integer choice;
		Scanner sc= new Scanner(System.in);
		
		
		System.out.println("Enter your Choice:\n1)Enter Demand Draft Details\n2)Exit");
		choice= sc.nextInt();
		switch(choice){
		case 1:
		{
	////
			DemandDraft dd1= new DemandDraft();
			System.out.println("Enter the name of the customer:");
			dd1.setCname(sc.next());
			System.out.println("Enter customer phone number:");
			dd1.setPnum(sc.next());
			System.out.println("In Favour of:");
			dd1.setIfo(sc.next());
			System.out.println("Enter Demand Draft amount (in Rs.):");
			dd1.setDdamt(sc.nextDouble());
			System.out.println("Enter Remarks:");
			dd1.setDd_desc(sc.next());
			DemandDraftService ds=new DemandDraftService();
			if(ds.addDemandDraftDetails(dd1)==0){
				System.out.println("Exceptions errors");
				System.out.println("Demand Draft Application closing***\n closed**");
				System.exit(0);
			}
			System.out.println("Your Demand Draft request has been successfully registered along with the "+dd1.getTid());
			break;
			////
		}
		case 2:{
			sc.close();
			System.out.println("Demand Draft Application closing***\n closed**");
			System.exit(0);
		}
		sc.close();
		System.out.println("Demand Draft Application closing***\n closed**");
		}
	}
}
