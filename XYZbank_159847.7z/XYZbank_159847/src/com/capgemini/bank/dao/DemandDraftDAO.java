package com.capgemini.bank.dao;

import java.sql.DriverManager;


import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import com.capgemini.bank.bean.DemandDraft;


public class DemandDraftDAO implements IDemandDraftDAO {

	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException  {
		Date d = new Date();
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		}
		catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		String user="hr";
		String pass="hr";
	
		Connection con= DriverManager.getConnection(url,user,pass);
		

		String sql="insert into demand_draft values(?,?,?,?,?,?,?,?)";
		
		/*(1)transaction_id NUMBER,(2)customer_name VARCHAR2(20),
		 * (3)in_favor_of  VARCHAR2(20), 
		(4)phone_number VARCHAR2(10),(5) date_of_transaction DATE,
		(6) dd_amount NUMBER, 
		(7)dd_commission NUMBER, 
		(8)dd_description VARCHAR2(50)*/
		
		PreparedStatement ps=con.prepareStatement(sql);
		Statement st=con.createStatement(); //import using java.sql not java.beans
		ResultSet rs=st.executeQuery("select Transaction_id_Seq.nextval from dual");
		while(rs.next()){
		demandDraft.setTid(Integer.valueOf(rs.getInt(1)));
		}
		ps.setInt(1,demandDraft.getTid());
		ps.setString(2,demandDraft.getCname());
		ps.setString(3, demandDraft.getIfo());
		ps.setString(4, demandDraft.getPnum());
		ps.setDate(5, new java.sql.Date(d.getTime()));
		ps.setDouble(6, demandDraft.getDdamt());
		ps.setDouble(7,demandDraft.getDdcomm());
		ps.setString(8, demandDraft.getDd_desc());
		ps.executeUpdate();
		System.out.println("1 row inserted");
		con.close();
		return 0;
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) {
		
		return null;
	}
	

}
