package com.cg.servlet;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String id= request.getParameter("eid");
		String newempname= request.getParameter("newempname");
		String newempsalary= request.getParameter("newempsalary");
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url= "jdbc:oracle:thin:@localhost:1521:XE";
			String user= "hr";
			String pass= "hr";
			Connection con= DriverManager.getConnection(url,user,pass);
			String sql="Update employeed set ename=?,esal=? where id=?";
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setString(1,newempname );
			ps.setDouble(2, Double.parseDouble(newempsalary));
			ps.setInt(3,Integer.parseInt(id) );
			int n= ps.executeUpdate();
			if(n>=1){
				RequestDispatcher rd= request.getRequestDispatcher("viewEmployees.jsp");
				rd.forward(request,response);
			}
			else{
				out.println("<b style='color:red'>Something went wrong</b>");
				RequestDispatcher rd= request.getRequestDispatcher("updateEmployee.jsp?id"+id);
				rd.include(request,response);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}
