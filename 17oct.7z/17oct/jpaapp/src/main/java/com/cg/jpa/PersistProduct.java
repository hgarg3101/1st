package com.cg.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PersistProduct {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("jpaapp");
		EntityManager entity=factory.createEntityManager();
		entity.getTransaction().begin();
		Product p= new Product();
		p.setId(101);
		p.setName("Iphone 6s");
		p.setPrice(45000);
		entity.persist(p);   //inserting the record
		entity.getTransaction().commit();
		System.out.println("product persisted...");

	}

}
