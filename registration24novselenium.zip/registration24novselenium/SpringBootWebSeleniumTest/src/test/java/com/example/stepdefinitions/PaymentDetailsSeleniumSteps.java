package com.example.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PaymentDetailsSeleniumSteps {
	private String baseUrl = "http://localhost:9998/PaymentDetails";
	private String path_to_driver = "D:\\srinivas_12sep_garg\\4th_6nov(TopUP)\\Spring_content_5nov\\github_sirinivas\\";
	private WebDriver driver = null;
	
	private static WebElement cardholdernameelement = null;
	private static WebElement debitcardnumberelement = null;
	private static WebElement cvvelement = null;
	private static WebElement expirationmonthelement = null;
	private static WebElement expirationyearelement = null;

	@Before
	public void setChromeDriver() {
		

		System.setProperty("webdriver.chrome.driver", path_to_driver + "chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(baseUrl);
		cardholdernameelement = driver.findElement(By.id("txtCardholderName"));
		debitcardnumberelement = driver.findElement(By.id("txtDebit"));
		cvvelement = driver.findElement(By.id("txtCvv"));
		expirationmonthelement = driver.findElement(By.id("txtMonth"));
		expirationyearelement = driver.findElement(By.id("txtYear"));

	}

	@After
	public void closeDriver() {
		try {
			Thread.sleep(2000);
			driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Given("^User is on Payment Details page$")
	public void user_is_on_Payment_Details_page() throws Throwable {
		Assert.assertEquals(driver.getTitle(), "Payment Details");
	}

	@When("^User does not input value for 'Card Holder Name'$")
	public void user_does_not_input_value_for_Card_Holder_Name() throws Throwable {

	}

	@When("^User click on Make Payment link$")
	public void user_click_on_Make_Payment_link() throws Throwable {
		driver.findElement(By.id("btnPayment")).click();
	}

	@Then("^Alert message should be displayed 'Please fill the Card holder name'\\.$")
	public void alert_message_should_be_displayed_Please_fill_the_Card_holder_name() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String str = alert.getText();
		alert.accept();
		Assert.assertEquals(str, "Please fill the Card holder name");
	}

	@When("^User does not input value for 'Debit Card Number'$")
	public void user_does_not_input_value_for_Debit_Card_Number() throws Throwable {
		cardholdernameelement.sendKeys("test");
		
	}

	@Then("^Alert message should be displayed 'Please fill the Debit card Number'\\.$")
	public void alert_message_should_be_displayed_Please_fill_the_Debit_card_Number() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String str = alert.getText();
		alert.accept();
		Assert.assertEquals(str, "Please fill the Debit card Number");
	}

	@When("^User does not input value for 'CVV'$")
	public void user_does_not_input_value_for_CVV() throws Throwable {
		debitcardnumberelement.sendKeys("test");
	}

	@Then("^Alert message should be displayed 'Please fill the CVV'\\.$")
	public void alert_message_should_be_displayed_Please_fill_the_CVV() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String str = alert.getText();
		alert.accept();
		Assert.assertEquals(str, "Please fill the CVV");
	}

	@When("^User does not input value for 'Expiration month'$")
	public void user_does_not_input_value_for_Expiration_month() throws Throwable {
		cvvelement.sendKeys("test");
		
	}

	@Then("^Alert message should be displayed 'Please fill expiration month'\\.$")
	public void alert_message_should_be_displayed_Please_fill_expiration_month() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String str = alert.getText();
		alert.accept();
		Assert.assertEquals(str, "Please fill expiration month");
	}

	@When("^User does not input value for 'Expiration Year'$")
	public void user_does_not_input_value_for_Expiration_Year() throws Throwable {
		expirationmonthelement.sendKeys("test");
	}

	@Then("^Alert message should be displayed 'Please fill the expiration year'\\.$")
	public void alert_message_should_be_displayed_Please_fill_the_expiration_year() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String str = alert.getText();
		alert.accept();
		Assert.assertEquals(str, "Please fill the expiration year");
	}

	@When("^User input value for \"([^\"]*)\" & \"([^\"]*)\" & \"([^\"]*)\"& \"([^\"]*)\" & \"([^\"]*)\"$")
	public void user_input_value_for(String arg1, String arg2, String arg3, String arg4, String arg5) throws Throwable {
		cardholdernameelement.sendKeys(arg1);
		debitcardnumberelement.sendKeys(arg2);
		cvvelement.sendKeys(arg3);
		expirationmonthelement.sendKeys(arg4);
		expirationyearelement.sendKeys(arg5);
	}

	@Then("^Alert message should be displayed 'Conference Room Booking successfully done!!!'\\.$")
	public void alert_message_should_be_displayed_Conference_Room_Booking_successfully_done() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String str = alert.getText();
		alert.accept();
		Assert.assertEquals(str, "Conference Room Booking successfully done!!!");
	}

}
