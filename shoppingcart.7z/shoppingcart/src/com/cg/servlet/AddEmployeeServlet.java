package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddEmployeeServlet
 */
@WebServlet("/AddEmployeeServlet")
public class AddEmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddEmployeeServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String empname= request.getParameter("empname");
		String empsalary= request.getParameter("empsalary");
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url= "jdbc:oracle:thin:@localhost:1521:XE";
			String user= "hr";
			String pass= "hr";
			Connection con= DriverManager.getConnection(url,user,pass);
			String sql= "Select eid_seq.nextval from dual";
			PreparedStatement ps= con.prepareStatement(sql);
			ResultSet rs= ps.executeQuery();
			int id=0;
			while(rs.next()){
			id= rs.getInt(1);
			}
			sql= "insert into employeed values(?,?,?)";
			ps=con.prepareStatement(sql);
			ps.setInt(1,id);
			ps.setString(2, empname);
			ps.setDouble(3,Double.parseDouble(empsalary));
			//ps.setString(3, empsalary); oracle database will treat string accordingly;
			int n= ps.executeUpdate();
			if(n>=1){
				out.println("Employee details added");
				RequestDispatcher rd= request.getRequestDispatcher("addEmployee.jsp");
				rd.include(request,response);
			}
			else{
				out.println("<b style='color:red'>Something went wrong</b>");
				RequestDispatcher rd= request.getRequestDispatcher("addEmployee.jsp");
				rd.include(request,response);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}
