package org.capgemini;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import org.capgemini.model.Employee;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EmployeeController {
	@RequestMapping("/home")
	public ModelAndView checklogin() {
		System.out.println("login activated");
		return new ModelAndView("home");
	}

	@RequestMapping("/success")
	public ModelAndView checklogin(HttpServletRequest request, HttpServletResponse res) {
		Employee obj = new Employee();
		obj.setName(request.getParameter("username"));
		obj.setDepart(request.getParameter("departname"));
		String msg="Data successfully" +request.getParameter("submit").toLowerCase()+"ed.";
		return new ModelAndView("success", "message", "msg");
	}

}
