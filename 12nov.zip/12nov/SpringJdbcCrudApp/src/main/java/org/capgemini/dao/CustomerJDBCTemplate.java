package org.capgemini.dao;
import java.util.GregorianCalendar;

import java.util.List;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.capgemini.model.Customer;
import org.capgemini.ui.MainApp;
import org.springframework.jdbc.core.JdbcTemplate;

public class CustomerJDBCTemplate implements CustomerDAO {
	static Logger Log=Logger.getLogger(MainApp.class.getName()); 
	private DataSource dataSource; 
	private JdbcTemplate jdbcTemplateObject;
	
	@Override
	public void setDataSource(DataSource ds) {
		this.dataSource=ds;
		this.jdbcTemplateObject=new JdbcTemplate(dataSource);

	}

	@Override
	public void create(String cname, String mobile, Double deposit, GregorianCalendar regdate) {
		String sql="insert into customer(custid,custname,mobile,deposit,reg_date) values(Cust_seq.nextval,?,?,?,?)";
		jdbcTemplateObject.update(sql,cname,mobile,deposit,regdate);
		Log.info("Created Record Name=" + cname );

	}

	@Override
	public Customer getCustomer(Integer custid) {
		String sql="select * from customer where custid=?";
		Customer customer=jdbcTemplateObject.queryForObject(sql, new Object[]{custid},new CustomerMapper());
		return customer;
	}

	@Override
	public List<Customer> listCustomers() {
		String sql="select * from customer";
		List<Customer> customers=jdbcTemplateObject.query(sql,new CustomerMapper());
		return customers;
	}

	@Override
	public void delete(Integer id) {
		String sql="delete from customer where custid=?";
		jdbcTemplateObject.update(sql, id);
		Log.info("Record " + id + " Deleted successfully" );
	}

	@Override
	public void update(Integer id, String mobile) {
		String sql="update customer set mobile=? where custid=?";
		jdbcTemplateObject.update(sql, mobile,id);
		Log.info("Record " + id + " Updated successfully" );
	}

}
 
