package org.capgemini.controller;



import org.capgemini.pojo.Customer;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

@Controller
@SessionAttributes
public class CustomerController {


/*@ModelAttribute will bind the data from request to the customer object.*/
	@RequestMapping(value="/showCustomer", method=RequestMethod.POST)
	public ModelAndView getCustomer( @ModelAttribute("customer") Customer customer, BindingResult result)
	{
		return new ModelAndView("showCustomer", "customer", customer);
	}
	
	@RequestMapping("/customer")
	public ModelAndView showCustomer()
	{
		return new ModelAndView("customer","command",new Customer());
	}
	
}
