package com.cg.jpa;

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class PersistStudent {

	public static void main(String[] args) throws IOException {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpapro");
		EntityManager em= emf.createEntityManager();
		em.getTransaction().begin();
		while(true){
		Integer choice;
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		
		Student s= new Student();
		Query q = em.createQuery("FROM Student");
		List<Student> list= q.getResultList();
		System.out.println("Welcome to user friendly application.\nEnter your choice please if you have time to waste, if not select exit");
		System.out.println("1. Add Employees\n2. Update\n3. Delete\n4. View\n5. Exit");
		choice= Integer.valueOf(br.readLine());
		switch(choice){
		case 1:{
			//adding employees
			System.out.println("Enter name for the worthless employee");
			s.setName(br.readLine());
			Address a= new Address();
			a.setCity("Hyderabad");
			a.setState("Ts");
			Address a1= new Address();
			a1.setCity("Vijayawada");
			a1.setState("AP");
			s.getAddress().add(a);
			s.getAddress().add(a1);
			em.persist(s);
			em.getTransaction().commit();
			System.out.println("Employee added...another mistake in a long list of regrettable life choices");
			break;
		}
		case 2:{
			//Updation employees
			System.out.println("Enter id to update");
			Integer id= Integer.valueOf(br.readLine());
			System.out.println("Enter name for the worthless employee,on which you want to waste your time to update data");
		
			for(Student s1: list){
				if(s1.getId()==id){
					s1.setName(br.readLine());
					em.persist(s1);
				}
			}
			em.getTransaction().commit();
			System.out.println("Update your brain not this Db");
			break;
		}
		case 3:{
			//delete employee
			System.out.println("Enter employee id to delete..(lucky person)");
			Integer id= Integer.valueOf(br.readLine());
			for(Student s1: list){
				if(s1.getId()==id){
					em.remove(s1);
				}
			}
			em.getTransaction().commit();
			System.out.println("Employee data deleted..see we are only fragment of cosmic dust and one day will be forgotten.\nIt doesn't matter what you do now and what you did in the past..\nif universe delete you from its database..your existence will be nothing.Your existence means nothing  ");
			break;
			
		}
		case 4:{
			//view employees
			System.out.println("See list of all who are stuck in the rat race.\nThese are who don't have any talent of their own or don't have guts to quit their jobs to follow their passion.. ");
			for(Student s1: list){
				System.out.println(s1.getId()+": "+s1.getName());
				}
			
			}
			break;
		
		
		case 5:{
			//exit code
			System.out.println("System exiting..Now go do some productive meaningful work.");
			em.close();
			emf.close();
			System.exit(0);
		}
		
		default:
		{
			System.out.println("You are worthless..you can't even put correct values..your company is doommed.\n\n");
		}
		
		}
		}
	}

}
