package com.capgemini.pojo.SpringDBApp;

import java.sql.Connection;
import java.sql.DriverManager;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DataBaseUI {
	
	public static void main(String[] args) {
		AbstractApplicationContext context= new ClassPathXmlApplicationContext("DBapp-config.xml");
		OracleDBDetails odb= (OracleDBDetails)context.getBean("dbdetails");
		odb.checkconnection();
	
	}

}
