package com.capgemini.pojo.SpringDBApp;

import java.sql.Connection;
import java.sql.DriverManager;

public class OracleDBDetails{
	private String Schema;
	private String dbname;
	private Integer port;
	private String uname;
	private String password;
	private String hostname;
	
	public String getSchema() {
		return Schema;
	}
	public void setSchema(String schema) {
		Schema = schema;
	}
	public String getDbname() {
		return dbname;
	}
	public void setDbname(String dbname) {
		this.dbname = dbname;
	}
	public Integer getPort() {
		return port;
	}
	public void setPort(Integer port) {
		this.port = port;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getHostname() {
		return hostname;
	}
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	public void checkconnection() { //sushant this is a method
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc"+":"+getDbname()+":"+"thin"+":"+getHostname()+":"+getPort()+":"+getSchema();
			String user=getUname();
			String pass=getPassword();
			
			Connection con=DriverManager.getConnection(url,user,pass);
			
			if(!con.isClosed()) {
				System.out.println("yayy!! successfully connected");
			}
			else {
				System.out.println("Connection failed");
			}
			
		}
		catch(Exception e){
			
			e.printStackTrace();
		}
	}
}
