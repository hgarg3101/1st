package com.cap.main;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cap.config.MyConfigurations;
import com.cap.model.SpringAnnotationDemo.Employee;

public class MainClass {
	static Logger Log=Logger.getLogger(Employee.class.getName()); 
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(MyConfigurations.class);
		
		Employee employee1=(Employee)context.getBean("employee");
		System.out.println(employee1);
		Log.info("\n\n\nDetails from code::"+employee1+"\n\n");
	}

}
