package com.cap.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.cap.model.SpringAnnotationDemo.Department;
import com.cap.model.SpringAnnotationDemo.Employee;

@Configuration
public class MyConfigurations {

	@Bean(name = "employee")
	public Employee getEmployee() {
		return new Employee(1001, "tom", "jerry", 12000.0);
	}

	@Bean(name = "employee1")
//	@Scope("prototype")
	public Employee getEmployeeObject() {
		return new Employee(1003, "other tom", "other jerry", 32000.0);
	}
	@Bean(name = "employee2")
	public Employee getEmployee2() {
		return new Employee(1001, "tom", "jerry", 12000.0);
	}
	@Bean(name = "depart")
	public Department getDepartmentObject() {
		return new Department(15, "Sales");
	}

}
