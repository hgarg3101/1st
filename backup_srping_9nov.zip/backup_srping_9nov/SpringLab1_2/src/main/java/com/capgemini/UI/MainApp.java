package com.capgemini.UI;

import org.apache.log4j.Logger;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.pojo.HelloWorld;

public class MainApp {
	static Logger Log=Logger.getLogger(HelloWorld.class.getName()); 
	public static void main(String[] args) {
		AbstractApplicationContext context= new ClassPathXmlApplicationContext("LAbapp-config.xml");
		
		//scope is singleton
		HelloWorld hw1=(HelloWorld)context.getBean("helloWorld");
		hw1.setMessage("I am helloWorld");		
		HelloWorld hw2=(HelloWorld)context.getBean("helloWorld");
		Log.info("\n\nProgram output:\nWhen Scope is singleton\n"+hw1.getMessage());
		Log.info(hw2.getMessage()+"\n\n\n");
		
		
		//scope is prototype
		HelloWorld hw3=(HelloWorld)context.getBean("helloWorld1");
		hw3.setMessage("I am new helloWorld");		
		HelloWorld hw4=(HelloWorld)context.getBean("helloWorld1");
		Log.info("\n\nProgram output:\nWhen Scope is prototype\n"+hw3.getMessage());
		Log.info(hw4.getMessage()+"\n\n\n");
		
		
	
	}
}
