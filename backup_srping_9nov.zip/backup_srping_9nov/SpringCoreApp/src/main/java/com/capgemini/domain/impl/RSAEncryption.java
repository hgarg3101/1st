package com.capgemini.domain.impl;

import com.capgemini.domain.Encryption;

public class RSAEncryption implements Encryption {

	public void encryptData() {
		System.out.println("Encryption data");
		
	}

}
