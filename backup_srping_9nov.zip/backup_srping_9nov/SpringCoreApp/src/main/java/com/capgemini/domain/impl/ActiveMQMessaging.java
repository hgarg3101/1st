package com.capgemini.domain.impl;

import com.capgemini.domain.Messaging;

public class ActiveMQMessaging implements Messaging {

	public void sendMessage() {
		System.out.println("Sending message via Active MQ"); //Messaging queue services
		
	}
	

}
