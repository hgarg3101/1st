package com.capgemini.domain;

public interface Messaging {
	public void sendMessage();
}
