package com.capgemini.pojo;

import org.apache.log4j.Logger;

import com.capgemini.UI.MainApp;

public class SpellChecker {
	static Logger Log=Logger.getLogger(MainApp.class.getName()); 
	public SpellChecker()
	{
		Log.info("Inside SpellCheker Constructor....");
	}
	public void checkSpelling()
	{
		Log.info("Inside SpellChecking");
	}
}
