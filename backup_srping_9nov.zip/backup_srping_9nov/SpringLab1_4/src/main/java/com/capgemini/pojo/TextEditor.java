package com.capgemini.pojo;

import org.apache.log4j.Logger;

import com.capgemini.UI.MainApp;

public class TextEditor {
	static Logger Log=Logger.getLogger(MainApp.class.getName()); 
 private SpellChecker spellChecker;
 public TextEditor() {
//	super();
}



public TextEditor(SpellChecker spellChecker)
 {
	 Log.info("Text Editor Constructor");
	 this.spellChecker=spellChecker;
 }
 
 

public void setSpellChecker(SpellChecker spellChecker) {
	this.spellChecker = spellChecker;
}


public void spellCheck()
 {
	 spellChecker.checkSpelling();
 }
}
