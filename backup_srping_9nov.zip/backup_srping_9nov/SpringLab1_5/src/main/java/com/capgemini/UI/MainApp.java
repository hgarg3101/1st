package com.capgemini.UI;

import org.apache.log4j.Logger;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.pojo.TextEditor;

public class MainApp {
	static Logger Log=Logger.getLogger(MainApp.class.getName()); 
	public static void main(String[] args) {
		ApplicationContext context= new ClassPathXmlApplicationContext("LAbapp-config.xml");
		Log.info("When autowire=by type");
		TextEditor tx=(TextEditor)context.getBean("textEditor");
		Log.info("spell check method of texteditor is called");
		tx.spellCheck();
		Log.info("When autowire=by Name");
		TextEditor tx1=(TextEditor)context.getBean("textEditor1");
		Log.info("spell check method of texteditor is called");
		tx1.spellCheck();
	}
}
