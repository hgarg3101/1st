package com.capgemini.pojo;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class InitHelloWorld implements BeanPostProcessor { 
	static Logger Log=Logger.getLogger(HelloWorld.class.getName()); 
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException { 
		Log.info("BeforeInitialization : " + beanName); 
		return bean; // you can return any other object as well 
} 
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException { 
		Log.info("AfterInitialization : " + beanName); 
		return bean; // you can return any other object as well 
} 
}
