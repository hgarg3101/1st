package com.capgemini.UI;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.pojo.HelloWorld;

public class MainApp {
	static Logger Log=Logger.getLogger(HelloWorld.class.getName()); 
	public static void main(String[] args) {
		AbstractApplicationContext context= new ClassPathXmlApplicationContext("LAbapp-config.xml");
		HelloWorld obj= (HelloWorld) context.getBean("helloWorld");
		
		Log.info("\n\nProgram output:\n"+obj.getMessage()+"\n\n\n");
		 context.registerShutdownHook();
	}

}
