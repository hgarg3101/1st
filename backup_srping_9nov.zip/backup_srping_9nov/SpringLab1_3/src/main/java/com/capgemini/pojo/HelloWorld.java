package com.capgemini.pojo;

import org.apache.log4j.Logger;

public class HelloWorld {
	static Logger Log=Logger.getLogger(HelloWorld.class.getName()); 
	private String message;

	public String getMessage() {
		return "My message: "+message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	public void init(){ 
		Log.info("Bean Initialization Here."); 
		} 
	public void destroy(){ 
		Log.info("Bean will destroy now."); 
	}
	
}
