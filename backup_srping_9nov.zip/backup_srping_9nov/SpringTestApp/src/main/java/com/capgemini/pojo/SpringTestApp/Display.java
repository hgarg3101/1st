package com.capgemini.pojo.SpringTestApp;

public class Display {
	int var;
	String str;
	
	/*Display(Integer var1, String  str1){
		this.var=var1;
		this.str=str1;
	}*/

	public void setVar(int var) {
		this.var = var;
	}

	public void setStr(String str) {
		this.str = str;
	}

	public int getVar() {
		return var;
	}

	public String getStr() {
		return str;
	}
	
	
}
