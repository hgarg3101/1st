import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.pojo.SpringTestApp.Display;

public class TestUI {
	public static void main(String...a) {
		AbstractApplicationContext context= new ClassPathXmlApplicationContext("Testapp-config.xml");
		Display dispobj1=(Display)context.getBean("dispobj");
		System.out.println("Number: "+dispobj1.getVar()+"\n"+"Name: "+dispobj1.getStr());
	}
}
