package com.capgemini.pojo.SpringSICollectionApp;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Employee {
	Integer emp_no;
	List<Object> depart_no;
	
//spring only knows List,set,map interface. It won't support implementation classes. Must do it manually.
	
	Employee(Integer emp_no,List<Object> depart_no){
		this.emp_no=emp_no;
		this.depart_no=depart_no;
		
	}
	
	public Integer getEmp_no() {
		return emp_no;
	}

	public void setEmp_no(Integer emp_no) {
		this.emp_no = emp_no;
	}

	public List<Object> getDepart_no() {
		return depart_no;
	}

	public void setDepart_no(List<Object> depart_no) {
		this.depart_no = depart_no;
	}
	
	public String toString() {
		return "emp_no: "+emp_no+"\ndepart_no: "+depart_no.get(0) ;
		
	}

}
