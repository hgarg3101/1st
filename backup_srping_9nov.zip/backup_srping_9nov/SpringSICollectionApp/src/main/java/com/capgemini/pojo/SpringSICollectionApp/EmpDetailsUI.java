package com.capgemini.pojo.SpringSICollectionApp;

import org.apache.log4j.Logger;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class EmpDetailsUI {
	static Logger Log=Logger.getLogger(Employee.class.getName()); 
	public static void main(String[] args) {
		
		AbstractApplicationContext context= new ClassPathXmlApplicationContext("SICollectionapp-config.xml");
		Employee empobj= (Employee)context.getBean("empdetails");
		//spring only knows List,set,map interface. It won't support implementation classes. Must do it manually.
		empobj.getDepart_no().toArray();
//		System.out.println(empobj.getDepart_no());
		System.out.println(empobj);
		Log.info("test");
	}

}
