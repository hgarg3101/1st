//code for testing with test cases using junit.jar and hamcrest-core.jar

package com.capgemini.bank.service;
import static org.junit.Assert.*;


import java.sql.SQLException;

import  org.junit.Test;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;

public class MyJunitTest {

	@Test  //annotation test case1
	//method define for testing
	public void test1AddDetails() throws SQLException{ 
		DemandDraft demandDraft = new DemandDraft();
		demandDraft.setCname("Test capge");
		demandDraft.setPnum("9871234567");
		demandDraft.setIfo("My company");
		demandDraft.setDdamt(1000.0);  //double
		demandDraft.setDd_desc("Dd taken");
		demandDraft.setDdcomm(10.0);    //double
		DemandDraftService test = new DemandDraftService();
		assertEquals(1, test.addDemandDraftDetails(demandDraft));   //if successful will return 1
	}
	
	@Test  //annotation test case2
	
	public void test2AddDetails() throws SQLException{ 
		DemandDraft demandDraft = new DemandDraft();
		demandDraft.setCname("John");
		demandDraft.setPnum("9768587350");
		demandDraft.setIfo("Capgemini");
		demandDraft.setDdamt(45000.0);  //double
		demandDraft.setDd_desc("Dd taken in favor of Capgemini");
		demandDraft.setDdcomm(51.0);    //double
		DemandDraftService test = new DemandDraftService();
		assertEquals(1, test.addDemandDraftDetails(demandDraft));   //if successful will return 1
	}
	
	@Test  //annotation test case3
	//Failure test 
	public void test3AddDetails() throws SQLException{ 
		DemandDraft demandDraft = new DemandDraft();
		demandDraft.setCname("failure");
		demandDraft.setPnum("1234");  //will fail becuase of this
		demandDraft.setIfo("Capgemini");
		demandDraft.setDdamt(45000.0);  //double
		demandDraft.setDd_desc("Dd taken in favor of Capgemini");
		demandDraft.setDdcomm(51.0);    //double
		DemandDraftService test = new DemandDraftService();
		//failure test because it will return 0 due to exception errors
		assertEquals(0, test.addDemandDraftDetails(demandDraft));   //should return 0 because fail
	}
	
	
}
