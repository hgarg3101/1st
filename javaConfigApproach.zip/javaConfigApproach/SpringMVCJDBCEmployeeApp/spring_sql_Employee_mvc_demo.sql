
DROP TABLE Employee_MVC_demo;


CREATE TABLE Employee_MVC_demo(username VARCHAR(10),
departname VARCHAR2(10));
