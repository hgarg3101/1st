package org.capgemini.dao;

import javax.sql.DataSource;


import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeDAOImp implements EmployeeDAO{
	static Logger Log=Logger.getLogger(EmployeeDAOImp.class.getName()); 
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private DataSource dataSource;

//	public JdbcTemplate getJdbcTemplate() {
//		return jdbcTemplate;
//	}

	public void setJdbcImp(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void setDataSource(DataSource ds) {
		this.dataSource=ds;
		this.jdbcTemplate=new JdbcTemplate(dataSource);
		
	}

	public void insert(String username, String departname) {
		String sql="insert into Employee_MVC_demo(username,departname) values(?,?)";
		jdbcTemplate.update(sql,username,departname);
		Log.info("Created Record Name=" + username);
		
	}

	public void delete(String username) {
		String sql="delete from Employee_MVC_demo where username=?";
		jdbcTemplate.update(sql,username);
		Log.info("Record " +username + " Deleted successfully" );
		
	}

	public void update(String username, String departname) {
		String sql="update Employee_MVC_demo set username=?, departname=? where username=?";
		jdbcTemplate.update(sql,username,departname,username);
		Log.info("Record " +username + " Updated successfully" );
		
	}
}
