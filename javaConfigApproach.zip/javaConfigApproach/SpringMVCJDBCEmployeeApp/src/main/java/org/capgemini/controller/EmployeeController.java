package org.capgemini.controller;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import org.capgemini.configuration.MyConfig1;
import org.capgemini.dao.EmployeeDAOImp;
import org.capgemini.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
//import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeDAOImp empjdbcobj;
	
	@RequestMapping("/home")
	public ModelAndView checklogin() {
		System.out.println("login activated");
		return new ModelAndView("home");
	}

	@RequestMapping("/success")
	public ModelAndView checklogin(HttpServletRequest request, HttpServletResponse res) {
//		AnnotationConfigApplicationContext context=	new AnnotationConfigApplicationContext(MyConfig1.class);
		Employee obj = new Employee();
		obj.setUsername(request.getParameter("username"));
		obj.setDepartname(request.getParameter("departname"));
		String msg="Data successfully " +request.getParameter("submit").toLowerCase()+"ed.";
		if(request.getParameter("submit").toLowerCase().equals("insert")){
			empjdbcobj.insert(obj.getUsername(), obj.getDepartname());
		}
		else if(request.getParameter("submit").toLowerCase().equals("delete")){
			empjdbcobj.delete(obj.getUsername());
		}
		else if(request.getParameter("submit").toLowerCase().equals("update")){
			empjdbcobj.update(obj.getUsername(), obj.getDepartname());
		}
		return new ModelAndView("success", "message", msg);
	}

}
