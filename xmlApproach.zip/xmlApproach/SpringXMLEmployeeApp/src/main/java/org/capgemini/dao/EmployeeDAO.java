package org.capgemini.dao;

import java.util.GregorianCalendar;

import javax.sql.DataSource;

public interface EmployeeDAO {
	public void setDataSource(DataSource ds);
	public void insert(String username, String departname);
	public void delete(String username);
	public void update(String username, String departname);

}
