package com.cg.servlet.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class LoginDAO implements ILoginDAO {

	//persistence login in dao 
/*	public Connection getConnection(){
	
		return con;
	}
	*/
	public String validateUser(String username, String pass) {
	//	Connection con = getConnection();
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		String dbuser="hr";
		String dbpass="hr";
	
		Connection con = null;
		try {
			con = DriverManager.getConnection(url,dbuser,dbpass);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		String sql = "select name from users where password=?";
		
		/*CREATE table users(id number primary key,
				name varchar2(30), password varchar2(30))*/
		
	/*	insert into users values(1001,'murli','ilovesehwag')*/
		
	String checkname = null;
	try{
		Statement st = con.createStatement();
		
		//PreparedStatement ps = con.prepareStatement(sql);
		//ps.setString(1, pass);
		
		ResultSet rs=st.executeQuery(sql);
	   // System.out.println("no of rows  "+st.executeQuery().getRow());
		System.out.println("before while loop");
		if(!rs.next()){
			System.out.println("nkithignsd");
		}
		while(rs.isBeforeFirst()){
			rs.next();
			System.out.println(rs.getString("name"));
			 if(username ==(rs.getString(2))){
				 System.out.println("inside loop");
				 checkname=rs.getString(2);
			 }
		}
		System.out.println("After while loop");
	}
	catch(Exception e){
		System.out.println("query not proper check please");
		e.printStackTrace();
	}
		
		//can also do like this.
		/*	try {
			ps = con.prepareStatement(sql);
			ps.setString(1, pass);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs= ps.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		try {
			while(rs.next()){
				String checkname =(rs.getString(2));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}*/
	System.out.println(username);
		System.out.println(checkname);
		System.out.println(pass);
		return checkname;
	}

}
