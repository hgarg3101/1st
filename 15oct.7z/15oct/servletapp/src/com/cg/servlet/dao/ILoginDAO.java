package com.cg.servlet.dao;

public interface ILoginDAO {
	public String validateUser(String username, String pass);
}
