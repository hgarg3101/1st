package com.cg.servlet.service;

public interface ILoginService {
	public String validateUser(String username, String pass);
}
