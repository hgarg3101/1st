package com.cg.servlet.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlet.service.LoginService;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String username =request.getParameter("username");   //value same as name attribute in jsp file
		String password =request.getParameter("password"); 
		out.println("<html>");
		out.println("<body>");
		LoginService service = new LoginService();
		if(service.validateUser(username, password)==null){
			out.println("<h1>Wrong input</h1>");
		}
		else
		{
		//out.println("<h1>Username: "+ username +"<br/>"+"Password: "+password+"</h1>");
		out.println("<h1>Welcome: "+ username +"</h1>");
			//System.out.println("<h1>Welcome: "+ username +"</h1>");
		}
		out.println("<html>");
		out.println("<body>");
	}
}
