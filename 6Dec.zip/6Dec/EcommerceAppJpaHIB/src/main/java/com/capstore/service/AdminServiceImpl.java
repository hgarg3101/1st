package com.capstore.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.pojo.Admin;
import com.capstore.pojo.Customer;
import com.capstore.repository.AdminRepository;

@Service
public class AdminServiceImpl implements AdminService {
	
	@Autowired
    private AdminRepository adminRepository;
	
//	@Autowired
//	private Customer customer;

	
	@Override
	public List<Admin> getAllAdmins() {
		return (List<Admin>) adminRepository.findAll();
	}


	@Override
	public Admin getAdminById(String a_email) {
		
		return adminRepository.getAdminById(a_email);
	}


	@Override
	public boolean checkIfAdmin(String a_email) {
		
		return adminRepository.existsById(a_email);
	}


	@Override
	public void addCustomer(Customer c) {
		
		
	}

}
