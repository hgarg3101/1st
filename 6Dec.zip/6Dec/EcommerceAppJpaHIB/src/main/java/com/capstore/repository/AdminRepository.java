package com.capstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capstore.pojo.Admin;

@Repository
public interface AdminRepository extends JpaRepository<Admin, String> {
	
	
	//methods from crudrepository
	//save, findById,findAll,count,delete,existingByID
	
	
	//define any other methods acc to requirement
	
	@Query(value="SELECT a FROM Admin a WHERE a.a_email IN :id")
	public Admin getAdminById(@Param("id") String a_mail);

}
