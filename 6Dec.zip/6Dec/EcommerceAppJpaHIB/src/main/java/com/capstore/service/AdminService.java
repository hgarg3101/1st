package com.capstore.service;

import java.util.List;


import com.capstore.pojo.Admin;
import com.capstore.pojo.Customer;

public interface AdminService {
	
	public List<Admin> getAllAdmins();
	public Admin getAdminById(String a_email);
	public boolean checkIfAdmin(String a_email);
	public void addCustomer(Customer c);
	
}
