package com.capstore.pojo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Customer")
public class Customer {
	
	@Id
	@Column(name = "c_email")
	private String c_email;
	
	@Column(name="password")
	private String password;
	
	@Column(name="first_name")
	private String first_name;
	
	@Column(name="last_name")
	private String last_name;
	
	@Column(name="phone_no")
	private Long phone_no;
	
	@Column(name="address")
	private String address;
	
	@Column(name="email_verification")
	private String email_verfication;
	
	@Column(name="registration_date")
	private Date registration_date;

	public String getC_email() {
		return c_email;
	}

	public String getPassword() {
		return password;
	}

	public String getFirst_name() {
		return first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public Long getPhone_no() {
		return phone_no;
	}

	public String getAddress() {
		return address;
	}

	public String getEmail_verfication() {
		return email_verfication;
	}

	public Date getRegistration_date() {
		return registration_date;
	}

	public void setC_email(String c_email) {
		this.c_email = c_email;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public void setPhone_no(Long phone_no) {
		this.phone_no = phone_no;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setEmail_verfication(String email_verfication) {
		this.email_verfication = email_verfication;
	}

	public void setRegistration_date(Date registration_date) {
		this.registration_date = registration_date;
	}
	

}
