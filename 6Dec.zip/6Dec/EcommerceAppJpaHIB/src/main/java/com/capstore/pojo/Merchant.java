package com.capstore.pojo;

public class Merchant {

}
