package com.capstore.service;

import java.util.List;


import com.capstore.pojo.Customer;

public interface CustomerService {
	public List<Customer> getAllCustomers();
	public Customer getCustomernById(String c_email);
	public boolean checkIfCustomer(String c_email);
}
