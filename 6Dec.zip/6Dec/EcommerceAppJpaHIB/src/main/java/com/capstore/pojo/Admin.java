package com.capstore.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="admin")
public class Admin {
	
	@Id
	@Column(name = "a_email")
	private String a_email;
	
	@Column(name="password")
	private String password;

	public String getA_email() {
		return a_email;
	}

	public String getPassword() {
		return password;
	}
	
}
