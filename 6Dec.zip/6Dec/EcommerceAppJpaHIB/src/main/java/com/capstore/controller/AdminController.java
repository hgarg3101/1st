package com.capstore.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.capstore.pojo.Admin;
import com.capstore.pojo.Customer;

import com.capstore.service.AdminService;
import com.capstore.service.CustomerService;

@RestController
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
    private CustomerService customerService;
	
	
	@RequestMapping("/")
	public String homepage() {
		return "nothing here";
	}
	
	//@ResponseStatus(HttpStatus.OK)
	@GetMapping("all")
	public ResponseEntity<List<Admin>> getAllAdmins() {
		List<Admin> list=adminService.getAllAdmins();
		System.out.println(list.get(0).getA_email()+"url called");
		HttpHeaders headers = new HttpHeaders();
	    headers.add("Access-Control-Allow-Origin", "*");
		return new ResponseEntity<List<Admin>>(list, headers, HttpStatus.OK);
	}
	
	@GetMapping("allCustomers")
	public ResponseEntity<List<Customer>> getAllCustomers() {
		List<Customer> list=customerService.getAllCustomers();
		System.out.println("getAllCustomers method called");
		HttpHeaders headers = new HttpHeaders();
	    headers.add("Access-Control-Allow-Origin", "*");
		return new ResponseEntity<List<Customer>>(list, headers, HttpStatus.OK);
	}
	
	@GetMapping("{a_email}")
	public ResponseEntity<Admin> getAdmin(@PathVariable String a_email) {
		Admin admin=adminService.getAdminById(a_email);
		System.out.println(admin.getA_email()+" "+admin.getPassword()+" "+"url called");
		HttpHeaders headers = new HttpHeaders();
	    headers.add("Access-Control-Allow-Origin", "*");
		return new ResponseEntity<Admin> (admin,headers, HttpStatus.OK);
	}
	

	/*@PostMapping("login")
//	@ResponseBody
	public ResponseEntity getUserDetails(@RequestBody Admin admin) {
		System.out.println("test");
		Admin admin1=adminService.getAdminById(admin.getA_email());
		System.out.println(admin1.getA_email()+" admin--"+admin.getA_email());
		HttpHeaders headers = new HttpHeaders();
	    headers.add("Access-Control-Allow-Origin", "*");
		if(admin1.getPassword().equals(admin.getPassword())) {
			return new ResponseEntity(headers, HttpStatus.OK);
		}
		return new ResponseEntity(headers, HttpStatus.NOT_FOUND);
	}*/
}
