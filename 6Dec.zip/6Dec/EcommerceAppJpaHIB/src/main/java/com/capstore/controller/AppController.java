package com.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.pojo.Admin;
import com.capstore.pojo.Customer;
import com.capstore.service.AdminService;
import com.capstore.service.CustomerService;

@RestController
@RequestMapping("/login")
public class AppController {
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
    private CustomerService customerService;
	
	@PostMapping("/")
//	@ResponseBody
	public Object getUserDetails(@RequestBody Admin admin) {
		System.out.println("test"+" 1233 --"+admin.getA_email());
		System.out.println(customerService.checkIfCustomer(admin.getA_email()));
		if(adminService.checkIfAdmin(admin.getA_email())) {
			Admin admin1=adminService.getAdminById(admin.getA_email());
			System.out.println(admin1.getA_email()+" admin--"+admin.getA_email());
			HttpHeaders headers = new HttpHeaders();
		    headers.add("Access-Control-Allow-Origin", "*");
			if(admin1.getPassword().equals(admin.getPassword())) {
				return new ResponseEntity(headers, HttpStatus.OK);
			}
			return new ResponseEntity(headers, HttpStatus.NOT_FOUND);
		}
		
		else if(customerService.checkIfCustomer(admin.getA_email())) {
			Customer customer= customerService.getCustomernById(admin.getA_email());
			if(customer.getPassword().equals(admin.getPassword())){
				return customer;
			}
		}
		return null;
	}
}
