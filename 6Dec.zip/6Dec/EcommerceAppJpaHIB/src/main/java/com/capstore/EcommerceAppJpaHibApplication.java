package com.capstore;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommerceAppJpaHibApplication {
	
	
	public static void main(String[] args) {
		 System.out.println("test");
		SpringApplication.run(EcommerceAppJpaHibApplication.class, args);
	}

}
