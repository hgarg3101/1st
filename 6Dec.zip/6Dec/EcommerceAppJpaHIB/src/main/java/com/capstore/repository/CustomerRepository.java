package com.capstore.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.capstore.pojo.Customer;

@Repository
public interface CustomerRepository extends CrudRepository<Customer, String> {
	@Query(value="SELECT c FROM Customer c WHERE c.c_email IN :id")
	public Customer getCustomerById(@Param("id") String c_email);
}
